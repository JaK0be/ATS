package exceptions;

public class InvalidNumberOfArgumentsException extends Exception {
    private static final long serialVersionUID = -4608391217465248554L;
}
