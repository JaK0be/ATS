package exceptions;

public class UnknownCompareTypeException extends Exception {
    private static final long serialVersionUID = 4322847041855358807L;
}
