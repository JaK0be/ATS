package exceptions;

public class InvalidTimeIntervalException extends Exception {
    private static final long serialVersionUID = 2598305284365843597L;
}
