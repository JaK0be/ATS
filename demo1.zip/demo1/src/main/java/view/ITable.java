package view;

interface ITable {
    String toString();
}
