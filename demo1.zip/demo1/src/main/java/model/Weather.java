package model;

import java.time.LocalDateTime;
import java.util.Random;

class Weather {
    private static String winter = "Winter";
    private static String spring = "Spring";
    private static String summer = "Summer";
    private static String fall = "Fall";
    private static final String[] seasons = {
            winter, winter,
            spring, spring, spring,
            summer, summer, summer,
            fall, fall, fall,
            winter
    };

    // dantes estava de 1 a 12 e dava erro em dezembro, logo deve ser entre 0 e 11
    private String getSeason() {
        return seasons[LocalDateTime.now().getMonthValue() - 1];
    }

    public double getSeasonDelay() {
        Random a = new Random();
        switch (getSeason()){
            case "Summer":
                return a.nextDouble() % 0.1;

            case "Spring":
                return a.nextDouble() % 0.3;

            case "Fall":
                return a.nextDouble() % 0.35;

            default:
                return a.nextDouble() % 0.6;
        }
    }
}
